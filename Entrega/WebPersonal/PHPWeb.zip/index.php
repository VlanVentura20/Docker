<?php
$servidor = "localhost";
$usuario = "Admin";
$password = "4Vientos";
$base_datos = "WebPersonal";

// Crear la conexión
$conexion = new mysqli($servidor, $usuario, $password, $base_datos);

// Verificar la conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}


if (isset($_GET['nombre'])) {
  // Obtener el nombre del proyecto desde la URL
  $nombre = $_GET['nombre'];

  // Consulta para obtener la imagen correspondiente
  $sql = "SELECT Foto FROM proyectos WHERE Nombre = ?";
  $stmt = $conexion->prepare($sql);
  $stmt->bind_param("s", $nombre);
  $stmt->execute();
  $stmt->bind_result($foto);
  $stmt->fetch();
  $stmt->close();

  // Mostrar la imagen
  if ($foto) {
      header("Content-Type: image/jpeg"); // Cambia esto si la imagen no es JPEG
      echo $foto; // Muestra los datos de la imagen directamente
      exit; // Termina el script aquí para no ejecutar el resto del código
  } else {
      echo "No se encontró la imagen.";
      exit; // Termina el script aquí si no se encuentra la imagen
  }
}

// Consulta para obtener todos los proyectos
$sql = "SELECT * FROM proyectos";
$result = $conexion->query($sql);
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Izan Ventura</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css"
    rel="stylesheet">
</head>

  <body>


    <!--/////////////////////////////////////////////////////////////////////////
////////////////////////////////Barra de busqueda//////////////////////////// 
/////////////////////////////////////////////////////////////////////////////-->


    <nav class="navbar navbar-expand-xl text-bg-success">
      <div class="container-fluid">
        <a id="BInicio" class="navbar-brand" href="#">Inicio</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarBasic"
          aria-controls="navbarBasic" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse show" id="navbarBasic">
          <ul class="navbar-nav me-auto mb-2 mb-xl-0">
            <li class="nav-item">
              <a id="BProyectos" class="nav-link active" aria-current="page" href="#">Proyectos</a>
            </li>
            <li class="nav-item">
              <a id="BContacto" class="nav-link" href="#">Contacto</a>
            </li>
          </ul>
          <form class="d-flex" id="searchForm">
            <input id="search" class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
          </form>
        </div>
      </div>
    </nav>
    <div id="searchResults" class="container mt-3" style="display:none;">
      <h3>Resultados de Búsqueda</h3>
      <ul id="resultsList" class="list-group"></ul>
    </div>





    <!--/////////////////////////////////////////////////////////////////////////
//////////////////////////////////////Inicio///////////////////////////////// 
/////////////////////////////////////////////////////////////////////////////-->


    <div class="container-fluid">
      <div id="Inicio" class="col-12 text-bg-primary p-3 my-4">
        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-4 d-flex justify-content-center align-items-center">
              <img src="img/FotoInicio.avif" class="img-fluid rounded-start" alt="Imagen de presentación">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h2 class="card-title">Bienvenidos a mi página web</h2>
                <p class="card-text">
                  ¡Hola! Soy Izan Ventura, un apasionado del desarrollo web con años de experiencia en la creación de
                  soluciones innovadoras. Me especializo en el diseño de interfaces intuitivas y la optimización del
                  rendimiento de sitios web. Para mí, cada proyecto es una oportunidad para aprender algo nuevo y
                  superar
                  los límites de lo que la tecnología puede ofrecer.
                </p>
                <p class="card-text">
                  Mi enfoque siempre ha sido combinar creatividad con eficiencia. Creo firmemente que un sitio web no
                  solo
                  debe verse bien, sino también funcionar de manera impecable. He trabajado en una amplia variedad de
                  proyectos, desde pequeñas páginas personales hasta complejas plataformas empresariales, adaptando cada
                  solución a las necesidades específicas del cliente y del público objetivo. La satisfacción del usuario
                  final siempre es mi prioridad.
                </p>
                <p class="card-text">
                  El mundo del desarrollo web está en constante evolución, y mantenerse al día con las últimas
                  tecnologías
                  es esencial para ofrecer productos de calidad. A lo largo de mi carrera, me he especializado en
                  lenguajes como JavaScript, Python, y frameworks populares como React, Vue.js, y Node.js. Sin embargo,
                  siempre estoy explorando nuevas herramientas y metodologías para mejorar mis habilidades y ampliar mi
                  experiencia. Últimamente, me he interesado en el desarrollo de aplicaciones móviles y el uso de
                  tecnologías como Flutter y React Native.
                </p>
                <p class="card-text">
                  Para mí, el desarrollo no se trata solo de código, sino de colaboración y comunicación. Disfruto
                  trabajar en equipo, compartir conocimientos, y aprender de mis colegas. También me apasiona contribuir
                  a
                  la comunidad tecnológica a través de charlas, mentorías, y colaboraciones en proyectos de código
                  abierto. Creo que la tecnología tiene el poder de cambiar el mundo y me esfuerzo por ser parte de esa
                  transformación.
                </p>
                <p class="card-text">
                  A largo plazo, mi objetivo es seguir creciendo como desarrollador y liderar proyectos que tengan un
                  impacto positivo en la sociedad. Estoy convencido de que la clave del éxito radica en la combinación
                  de
                  habilidades técnicas, creatividad, y un enfoque centrado en el usuario. Si tienes una idea o proyecto
                  en
                  mente, no dudes en ponerte en contacto conmigo. Estoy siempre abierto a nuevas oportunidades de
                  colaboración y crecimiento.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>


           <!--/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////Proyectos///////////////////////////////
/////////////////////////////////////////////////////////////////////////////-->

<div id="Proyectos" class="text-bg-warning container my-5">
    <h2 class="text-center mb-4">Mis Proyectos</h2>
    <div class="row">
        <?php
        if ($result->num_rows > 0) {
            // Salida de datos de cada fila
            while ($row = $result->fetch_assoc()) {
              echo '<div class="col-lg-4 col-md-6 mb-4">';
              echo '  <div class="card project-card" data-project="' . htmlspecialchars($row['Nombre']) . '">';
              echo '    <img src="?nombre=' . urlencode($row['Nombre']) . '" class="card-img-top" alt="' . htmlspecialchars($row['Nombre']) . '">';
              echo '    <div class="card-body">';
              echo '      <h5 class="card-title">' . htmlspecialchars($row['Nombre']) . '</h5>';
              echo '      <p class="card-text">Haz clic para ver más detalles</p>';
              echo '    </div>';
              echo '  </div>';
              echo '</div>';
            }
        } else {
            echo '<p class="text-center">No hay proyectos disponibles en este momento.</p>';
        }

        // Cierra la conexión
        $conexion->close();
        ?>
    </div>
</div>

      <!--/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////Contacto//////////////////////////////// 
/////////////////////////////////////////////////////////////////////////////-->

      <div id="Contacto" class="container my-5">
        <h2 class="text-center mb-4">Ponte en Contacto</h2>

        <form action="mailto:izan.venturav@gmail.com" method="POST" enctype="text/plain">
          <div class="mb-3">
            <label for="name" class="form-label">Nombre completo</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Escribe tu nombre" required>
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">Correo electrónico</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="nombre@ejemplo.com" required>
          </div>
          <div class="mb-3">
            <label for="subject" class="form-label">Asunto</label>
            <input type="text" class="form-control" id="subject" name="subject" placeholder="Motivo del contacto"
              required>
          </div>
          <div class="mb-3">
            <label for="message" class="form-label">Mensaje</label>
            <textarea class="form-control" id="message" name="message" rows="5" placeholder="Escribe tu mensaje aquí"
              required></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
      </div>


      <!--/////////////////////////////////////////////////////////////////////////
//////////////////////////////////////Footer///////////////////////////////// 
/////////////////////////////////////////////////////////////////////////////-->


      <footer class="bg-light text-center text-lg-start mt-4">
        <div class="container p-4">
          <section class="mb-4">
            <a class="btn btn-outline-dark btn-floating m-1" href="https://www.facebook.com/izan.ventura" role="button"
              target="_blank">
              <i class="bi bi-facebook"></i>
            </a>
            <a class="btn btn-outline-dark btn-floating m-1" href="https://twitter.com/izan_ventura" role="button"
              target="_blank">
              <i class="bi bi-twitter"></i>
            </a>
            <a class="btn btn-outline-dark btn-floating m-1" href="https://www.instagram.com/izan.ventura/"
              role="button" target="_blank">
              <i class="bi bi-instagram"></i>
            </a>
            <a class="btn btn-outline-dark btn-floating m-1" href="https://www.linkedin.com/in/izan-ventura/"
              role="button" target="_blank">
              <i class="bi bi-linkedin"></i>
            </a>
          </section>

          <section class="container my-5">
            <div class="row">
              <div class="col-lg-6 col-md-12 mb-4 pe-5">
                <h5 class="text-uppercase">Sobre nosotros</h5>
                <p>
                  Somos una empresa dedicada a la creación de proyectos web innovadores, enfocados en ofrecer la mejor
                  experiencia a nuestros usuarios.
                </p>
              </div>

              <div class="col-lg-6 col-md-6 mb-4 ps-5">
                <h5 class="text-uppercase">Contacto</h5>
                <ul class="list-unstyled">
                  <li><a href="mailto:izan.venturav@gmail.com" class="text-dark">Email</a></li>
                  <li><a href="tel:+123456789" class="text-dark">Teléfono</a></li>
                  <li class="text-dark">Dirección: Av. de San Jorge, 6, 31012 Pamplona, Navarra</li>
                </ul>
              </div>
            </div>
          </section>


        </div>

        <div class="text-center p-3 bg-dark text-light">
          © 2024 Izan Ventura. Todos los derechos reservados.
        </div>
      </footer>

      <script src="JavaScript/jquery-3.7.1.min.js"></script>
      <script src="JavaScript/Aplication.js"></script>
  </body>

  </html>